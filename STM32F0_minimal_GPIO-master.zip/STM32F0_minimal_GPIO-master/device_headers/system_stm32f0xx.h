#ifndef _VVC_DUMMY_STM32_SYSTEM
#define _VVC_DUMMY_STM32_SYSTEM

/* ST seems to use this file for keeping track of clock settings
 * in their applications. But we're managing that ourselves.
 * This file only exists so we don't have to comment out a line
 * in all of the device header files which contain macro
 * definitions for all of the peripheral registers.
 */

#endif
